Scott figured out edge cases and appropriate/expected regex expression that could capture them. Peter implemented the regex and tested them out and fixed any issues.
